"""
Local helper utilities for the GTA 6 Clip Studio.
This is a lightweight Python component, not a bundled neural AI model.
It can score timestamp candidates if an audio RMS series/transcript is supplied.
"""
import re

REACTION_TERMS = (
    "no way", "oh my", "what", "bro", "insane", "let's go",
    "help", "wow", "run", "are you serious", "get out"
)

def score_candidate(rms_values, transcript=""):
    """Return a transparent heuristic score from 1-100."""
    values = [max(0.0, float(v)) for v in rms_values]
    peak = max(values, default=0.0)
    mean = sum(values) / len(values) if values else 0.0
    dynamic = (peak - mean) / max(peak, 1e-9)
    words = transcript.lower()
    reaction_hits = sum(term in words for term in REACTION_TERMS)
    score = 35 + 45 * dynamic + min(20, reaction_hits * 5)
    return max(1, min(100, round(score)))

def make_post_copy(moment_type="Epic GTA 6 moment", topic="GTA 6"):
    safe_type = re.sub(r"[^A-Za-z0-9 ]", "", moment_type).strip()
    safe_topic = re.sub(r"[^A-Za-z0-9 ]", "", topic).strip()
    title = f"{safe_type or 'Gameplay highlight'} | {safe_topic or 'GTA 6'}"
    caption = f"{title} 😳🔥\\nFollow for more gaming clips!"
    hashtags = "#GTA6 #GTAVI #GTA6Gameplay #GamingClips #Shorts #Reels"
    return {"title": title, "caption": caption, "hashtags": hashtags}
