# GTA 6 Clip Studio — Android source project

## Included
- Android Gradle project (Kotlin + Android WebView).
- HTML/CSS/JavaScript dark gaming interface.
- Python helper module for heuristic moment scoring and post copy.
- On-device video selection and batch clip trimming using AndroidX Media3 Transformer.

## What this build actually does
- Imports a video file already stored on the phone.
- Lets you enter candidate timestamps and generate multiple clip ranges.
- Exports the selected ranges as MP4 locally on the phone.
- Generates a draft title, caption and hashtags.
- Includes a Python helper source file for heuristic scoring/copy generation.

## Important limitations — read before building
The supplied `stream-clips` SKILL.md describes a much larger desktop workflow: `yt-dlp` stream discovery/downloads, Whisper transcription, audio-volume analysis, chat replay analysis, AI moment selection, face detection, facecam/gameplay layouts, word-level captions, title overlays and audio leveling. The skill references `scripts/streamclips.py`, but that script was not included in the uploaded file. Therefore the full workflow cannot be faithfully ported from the supplied source alone.

This Android starter is **not yet a full AI auto-clipper**:
- No YouTube/Twitch/Kick URL downloading. Choose a video already saved on the device.
- No neural AI highlight detection in the APK yet. Current version asks you to enter timestamps manually.
- Python helper is included as source but is not embedded/executed in the APK yet.
- No Whisper model or automatic/burned-in captions.
- Export currently trims the source video; it does not yet reframe to 9:16, stack facecam/gameplay, add title bars, or normalize audio to -14 LUFS.
- Output is saved in app-specific Movies/GTA6Clips storage, not automatically in the public Gallery.

These are intentionally stated so the project is not mistaken for a finished AI clipping product. A true offline AI pipeline needs additional Android-compatible models and video/audio processing work and can be slow on mid-range phones.

## Build on an Android phone
Recommended mobile IDE: **Code on the Go** (actively maintained successor to AndroidIDE).
1. Install Code on the Go from https://appdevforall.org/code-on-the-go/
2. Download and extract this ZIP on your phone.
3. In Code on the Go, open the extracted project folder.
4. Allow it to install/setup its Android build toolchain.
5. Sync the Gradle project and resolve any dependency downloads.
6. Build the `app` debug APK from the Build menu.
7. Install the generated debug APK on your phone.

Compatibility note: Code on the Go's current toolchain supports Android Gradle Plugin 8.11.0 and Android phone builds. Its bundled Kotlin version may differ from the project's Kotlin plugin; if the IDE reports a Kotlin plugin/toolchain mismatch, change the Kotlin plugin version in root `build.gradle` to the version recommended by the installed Code on the Go release. See its official compatibility page: https://appdevforall.org/code-on-the-go/

Alternative: open the project in Android Studio on a computer with JDK 17+, Android SDK Platform 35 and internet access for the first Gradle sync.

## Source files
- `app/src/main/assets/index.html` — app UI
- `app/src/main/java/com/stylewithkitty/gta6clipper/MainActivity.kt` — Android bridge and local MP4 export
- `app/build.gradle` — Android dependencies
- `python/highlight_helper.py` — Python heuristic helper
