package com.stylewithkitty.gta6clipper

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Transformer
import java.io.File

@UnstableApi
class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var sourceUri: Uri? = null
    private var transformer: Transformer? = null
    private var exportQueue: ArrayDeque<Pair<Long, Long>> = ArrayDeque()
    private var exportIndex = 0
    private var totalExports = 0

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            sourceUri = uri
            web.evaluateJavascript("onVideoSelected(${jsonString(uri.toString())})", null)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface fun chooseVideo() { runOnUiThread { picker.launch(arrayOf("video/*")) } }
        @JavascriptInterface fun exportClips(rangesJson: String) {
            runOnUiThread {
                val uri = sourceUri
                if (uri == null) { notifyJs("showStatus('Choose a source video first.')"); return@runOnUiThread }
                try {
                    val arr = org.json.JSONArray(rangesJson)
                    exportQueue.clear()
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val start = (o.getDouble("start") * 1000).toLong().coerceAtLeast(0)
                        val end = (o.getDouble("end") * 1000).toLong()
                        if (end > start) exportQueue.add(Pair(start, end))
                    }
                    if (exportQueue.isEmpty()) { notifyJs("showStatus('No valid clip ranges.')"); return@runOnUiThread }
                    totalExports = exportQueue.size
                    exportIndex = 0
                    exportNext(uri)
                } catch (e: Exception) { notifyJs("showStatus(${jsonString("Could not read clip list: " + e.message)})") }
            }
        }
        @JavascriptInterface fun shareText(text: String) {
            runOnUiThread {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text)
                }
                startActivity(Intent.createChooser(send, "Share clip caption"))
            }
        }
    }

    private fun exportNext(uri: Uri) {
        if (exportQueue.isEmpty()) {
            notifyJs("showStatus('Export complete. Clips saved in app Movies folder.')")
            notifyJs("setProgress(100)")
            return
        }
        val (start, end) = exportQueue.removeFirst()
        exportIndex++
        val outDir = File(getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES), "GTA6Clips")
        outDir.mkdirs()
        val out = File(outDir, "gta6_clip_%02d.mp4".format(exportIndex))
        val clipping = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(start).setEndPositionMs(end).build()
        val item = MediaItem.Builder().setUri(uri).setClippingConfiguration(clipping).build()
        val edited = EditedMediaItem.Builder(item).build()
        transformer = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: androidx.media3.transformer.ExportResult) {
                    val pct = (exportIndex * 100 / totalExports)
                    notifyJs("setProgress($pct)")
                    notifyJs("addExportedClip(${jsonString(out.absolutePath)})")
                    exportNext(uri)
                }
                override fun onError(composition: androidx.media3.transformer.Composition, exportResult: androidx.media3.transformer.ExportResult, exportException: androidx.media3.transformer.ExportException) {
                    notifyJs("showStatus(${jsonString("Export error: " + exportException.message)})")
                    exportNext(uri)
                }
            }).build()
        transformer?.start(edited, out.absolutePath)
        notifyJs("showStatus(${jsonString("Exporting clip $exportIndex of $totalExports…")})")
    }

    private fun notifyJs(script: String) { web.evaluateJavascript(script, null) }
    private fun jsonString(s: String): String = org.json.JSONObject.quote(s)

    override fun onDestroy() {
        transformer?.cancel()
        web.destroy()
        super.onDestroy()
    }
}
